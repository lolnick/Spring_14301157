package resource;

import java.io.IOException;
import java.io.InputStream;


public class LocalFileResource implements Resource{
	private final String fileName;

    public LocalFileResource(String name) {
        this.fileName = name;
    }

    @Override
    public InputStream getInputStream() throws IOException{
    	 
        InputStream ins =LocalFileResource.class.getResourceAsStream("/"+fileName);
    	return ins;
    }
}